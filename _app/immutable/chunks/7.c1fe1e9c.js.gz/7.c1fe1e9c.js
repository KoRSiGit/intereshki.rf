import{default as t}from"../entry/(blog-article)-heraldic-page.md.614f7ea8.js";export{t as component};
