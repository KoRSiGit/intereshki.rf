import{default as t}from"../entry/(geocard)-mikl-page.md.3b910eb1.js";export{t as component};
