import{default as t}from"../entry/_error.svelte.de7f5aec.js";export{t as component};
