import{default as t}from"../entry/(waves)-slide-page.svelte.dc7919b5.js";export{t as component};
