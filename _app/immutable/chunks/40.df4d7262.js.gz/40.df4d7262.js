import{_ as r}from"./_page.8059cda0.js";import{default as t}from"../entry/(waves)-game-page.svelte.ba065013.js";export{t as component,r as universal};
