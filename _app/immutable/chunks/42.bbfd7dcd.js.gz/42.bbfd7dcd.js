import{default as t}from"../entry/(waves)-flashcards-page.svelte.2065b382.js";export{t as component};
