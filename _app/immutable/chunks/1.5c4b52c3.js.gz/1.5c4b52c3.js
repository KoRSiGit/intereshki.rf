import{default as t}from"../entry/_error.svelte.5e633392.js";export{t as component};
