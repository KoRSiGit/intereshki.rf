import{default as t}from"../entry/(blog-article)-march8-page.md.bb43bd5a.js";export{t as component};
