import{default as t}from"../entry/(subject-article)-layout.svelte.4601edb6.js";export{t as component};
