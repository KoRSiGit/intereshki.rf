import{default as t}from"../entry/(waves)-slide-ru-page.svelte.063ef0db.js";export{t as component};
