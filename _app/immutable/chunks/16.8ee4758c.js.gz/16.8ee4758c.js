import{default as t}from"../entry/(flashcard)-apply-page.md.e58e5465.js";export{t as component};
