import{default as t}from"../entry/(subject-article)-russian-formation-page.md.6c881b3b.js";export{t as component};
