import{default as t}from"../entry/(waves)-page.svelte.361c059a.js";export{t as component};
