import{default as t}from"../entry/(blog-article)-heraldic-elements-page.md.5212f0e8.js";export{t as component};
