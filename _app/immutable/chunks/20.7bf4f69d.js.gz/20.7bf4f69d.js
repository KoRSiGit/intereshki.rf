import{default as t}from"../entry/(flashcard)-mandatory-page.md.b6ded0a7.js";export{t as component};
