import{default as t}from"../entry/_error.svelte.5b1414f7.js";export{t as component};
