import{default as t}from"../entry/(waves)-404-page.svelte.26b839b6.js";export{t as component};
