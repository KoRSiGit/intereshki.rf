import{default as t}from"../entry/(geocard)-lazar-page.md.7d8aba70.js";export{t as component};
