import{default as t}from"../entry/(blog-article)-heraldic-guard-page.md.64364bae.js";export{t as component};
