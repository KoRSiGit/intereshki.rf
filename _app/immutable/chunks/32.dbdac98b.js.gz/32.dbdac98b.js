import{default as t}from"../entry/(subject-article)-culturology-page.md.e58cebf9.js";export{t as component};
