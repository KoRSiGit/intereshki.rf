import{default as t}from"../entry/(blog-article)-review-page.md.55046ec4.js";export{t as component};
