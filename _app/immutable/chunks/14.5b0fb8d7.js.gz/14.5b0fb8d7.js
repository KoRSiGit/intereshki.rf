import{default as t}from"../entry/(blog-article)-swift-page.md.a705e44b.js";export{t as component};
