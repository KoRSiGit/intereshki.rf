import{default as t}from"../entry/(subject-article)-countries-eng-rus-schools-1-page.md.1011d343.js";export{t as component};
