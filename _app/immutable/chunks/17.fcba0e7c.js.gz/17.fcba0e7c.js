import{default as t}from"../entry/(flashcard)-doubt-page.md.adcb9d60.js";export{t as component};
