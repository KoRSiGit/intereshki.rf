import{default as t}from"../entry/(flashcard)-institution-page.md.f1db7293.js";export{t as component};
