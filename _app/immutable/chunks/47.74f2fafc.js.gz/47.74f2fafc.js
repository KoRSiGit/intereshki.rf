import{default as t}from"../entry/(waves)-slide-ru-page.svelte.52a7465d.js";export{t as component};
