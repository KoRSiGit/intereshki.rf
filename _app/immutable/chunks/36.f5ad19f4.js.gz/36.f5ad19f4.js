import{default as t}from"../entry/(subject-article)-math-fraction-page.md.e46b0871.js";export{t as component};
