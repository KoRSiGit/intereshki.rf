import{default as t}from"../entry/(waves)-blog-page.svelte.c5240152.js";export{t as component};
