import{default as t}from"../entry/(blog-article)-snowflakes-page.md.130f0de8.js";export{t as component};
