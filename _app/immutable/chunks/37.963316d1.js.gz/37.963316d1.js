import{default as t}from"../entry/(subject-article)-phiz-running-page.md.ff05b178.js";export{t as component};
