import{default as t}from"../entry/(blog-article)-kamenka-page.md.02c46877.js";export{t as component};
