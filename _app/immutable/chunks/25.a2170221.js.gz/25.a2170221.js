import{default as t}from"../entry/(geocard)-lis_kruz-page.md.43c033b9.js";export{t as component};
