import{default as t}from"../entry/(blog-article)-heraldic-guard-page.md.81ac9fa4.js";export{t as component};
