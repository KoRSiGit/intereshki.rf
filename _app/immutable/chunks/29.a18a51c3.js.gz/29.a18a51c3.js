import{default as t}from"../entry/(geocard)-rgo-page.md.d6d7ef55.js";export{t as component};
