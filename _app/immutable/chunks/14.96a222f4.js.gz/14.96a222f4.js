import{default as t}from"../entry/(flashcard)-doubt-page.md.4c26aece.js";export{t as component};
