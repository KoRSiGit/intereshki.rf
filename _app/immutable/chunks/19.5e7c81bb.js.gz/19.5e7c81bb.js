import{default as t}from"../entry/(geocard)-bering-page.md.6c663253.js";export{t as component};
