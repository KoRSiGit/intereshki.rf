import{default as t}from"../entry/(waves)-404-page.svelte.207ec46f.js";export{t as component};
