import{default as t}from"../entry/(flashcard)-flexible-page.md.4cd3445f.js";export{t as component};
