import{default as t}from"../entry/(subject-article)-layout.svelte.862fb175.js";export{t as component};
