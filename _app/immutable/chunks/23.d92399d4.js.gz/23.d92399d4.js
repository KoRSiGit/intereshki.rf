import{default as t}from"../entry/(geocard)-dejnev-page.md.ff16e4ff.js";export{t as component};
