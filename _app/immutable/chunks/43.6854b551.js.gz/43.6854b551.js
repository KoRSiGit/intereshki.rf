import{_ as r}from"./_page.8c76f454.js";import{default as t}from"../entry/(waves)-game-page.svelte.901fdc68.js";export{t as component,r as universal};
