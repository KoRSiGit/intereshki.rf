import{default as t}from"../entry/(blog-article)-heraldic-elements-page.md.5508d4ec.js";export{t as component};
