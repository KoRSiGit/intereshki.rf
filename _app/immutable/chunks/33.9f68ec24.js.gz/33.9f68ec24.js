import{default as t}from"../entry/(subject-article)-english-past-cont-page.md.b523ab46.js";export{t as component};
