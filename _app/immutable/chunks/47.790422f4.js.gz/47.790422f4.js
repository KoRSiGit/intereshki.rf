import{_ as r}from"./_page.8059cda0.js";import{default as t}from"../entry/(waves)-resume-page.svelte.c5e06fe2.js";export{t as component,r as universal};
