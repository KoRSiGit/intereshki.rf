import{default as t}from"../entry/(waves)-slide-eng-page.svelte.e13735f2.js";export{t as component};
