import{default as t}from"../entry/(subject-article)-izo-mezen-page.md.570b80f2.js";export{t as component};
