import{default as t}from"../entry/(geocard)-prjev-page.md.17610cee.js";export{t as component};
