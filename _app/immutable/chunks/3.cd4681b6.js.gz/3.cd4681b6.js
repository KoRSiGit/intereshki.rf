import{default as t}from"../entry/(flashcard)-layout.svelte.2a5c5801.js";export{t as component};
