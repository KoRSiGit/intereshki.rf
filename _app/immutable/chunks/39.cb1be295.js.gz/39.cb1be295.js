import{default as t}from"../entry/(waves)-page.svelte.2c345023.js";export{t as component};
