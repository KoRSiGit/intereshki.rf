import{default as t}from"../entry/(blog-article)-kamenka-page.md.3c9fa703.js";export{t as component};
