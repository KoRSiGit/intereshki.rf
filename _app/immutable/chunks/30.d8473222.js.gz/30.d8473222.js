import{default as t}from"../entry/(subject-article)-biology-virus-page.md.0d80fc29.js";export{t as component};
