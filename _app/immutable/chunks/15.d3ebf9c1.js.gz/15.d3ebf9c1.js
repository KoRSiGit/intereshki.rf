import{default as t}from"../entry/(blog-article)-tardigrades-page.md.f022c985.js";export{t as component};
