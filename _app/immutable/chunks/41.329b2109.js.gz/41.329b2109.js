import{default as t}from"../entry/(waves)-blog-page.svelte.c3cec4ea.js";export{t as component};
