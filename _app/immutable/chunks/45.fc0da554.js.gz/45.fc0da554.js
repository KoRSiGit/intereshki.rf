import{_ as r}from"./_page.a2127be2.js";import{default as t}from"../entry/(waves)-quiz-page.svelte.b96ddd77.js";export{t as component,r as universal};
