import{default as t}from"../entry/(geocard)-rgo-page.md.96aae79b.js";export{t as component};
