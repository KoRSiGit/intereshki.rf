import{default as t}from"../entry/(geocard)-atlasov-page.md.270fa2c1.js";export{t as component};
