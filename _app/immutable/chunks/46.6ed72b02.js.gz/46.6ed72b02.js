import{_ as r}from"./_page.f1a8916d.js";import{default as t}from"../entry/(waves)-quiz-schools-page.svelte.4b374295.js";export{t as component,r as universal};
