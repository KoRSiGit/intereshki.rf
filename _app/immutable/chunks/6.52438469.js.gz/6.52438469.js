import{default as t}from"../entry/(waves)-layout.svelte.5a93e95e.js";export{t as component};
