import{default as t}from"../entry/(geocard)-atlasov-page.md.df72718d.js";export{t as component};
