import{default as t}from"../entry/(subject-article)-literature-review-page.md.f2e533ad.js";export{t as component};
