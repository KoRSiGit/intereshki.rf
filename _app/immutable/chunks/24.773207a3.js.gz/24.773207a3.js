import{default as t}from"../entry/(geocard)-lazar-page.md.ca117ffa.js";export{t as component};
