import{default as t}from"../entry/(blog-article)-heraldic-page.md.b530883d.js";export{t as component};
