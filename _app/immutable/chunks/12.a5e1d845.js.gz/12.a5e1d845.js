import{default as t}from"../entry/(blog-article)-review-page.md.feda159e.js";export{t as component};
