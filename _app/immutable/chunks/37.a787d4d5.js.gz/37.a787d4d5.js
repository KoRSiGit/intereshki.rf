import{default as t}from"../entry/(waves)-404-page.svelte.3a850cd7.js";export{t as component};
