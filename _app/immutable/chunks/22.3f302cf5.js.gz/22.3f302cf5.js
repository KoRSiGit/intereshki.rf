import{default as t}from"../entry/(geocard)-bering-page.md.3ac3ed82.js";export{t as component};
