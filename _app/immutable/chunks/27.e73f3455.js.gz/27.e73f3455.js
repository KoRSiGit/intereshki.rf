import{default as t}from"../entry/(geocard)-nikitin-page.md.d4fa97ee.js";export{t as component};
