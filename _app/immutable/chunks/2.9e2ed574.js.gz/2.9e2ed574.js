import{default as t}from"../entry/(blog-article)-layout.svelte.862fb175.js";export{t as component};
