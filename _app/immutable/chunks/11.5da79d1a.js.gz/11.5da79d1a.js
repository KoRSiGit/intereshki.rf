import{default as t}from"../entry/(blog-article)-march8-page.md.f8603291.js";export{t as component};
