import{default as t}from"../entry/(waves)-geocards-page.svelte.8cc0dd92.js";export{t as component};
