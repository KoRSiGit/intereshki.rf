import{default as t}from"../entry/(blog-article)-layout.svelte.4601edb6.js";export{t as component};
